from datamodel import OrderDepth, UserId, TradingState, Order
from typing import List
import string


PRODUCT_LIMITs = {
    "EMERALDS": 80,
    "TOMATOES": 80,
}


class Trader:
    def bid(self):
        return 15

    def _get_fair_price(self, product: str, state: TradingState):
        """Determine the fair price for a product based on the current state of the market."""

        if product == "EMERALDS":
            fair_price = 10000
        elif product == "TOMATOES":
            order_depth: OrderDepth = state.order_depths[product]
            best_ask, best_ask_amount = list(order_depth.sell_orders.items())[0]
            best_bid, best_bid_amount = list(order_depth.buy_orders.items())[0]
            fair_price = (best_ask + best_bid) / 2
        return fair_price

    def take_orders(self, fair_price: float, product: str, state: TradingState):
        """
        Take liquidity from the market
        """
        order_depth: OrderDepth = state.order_depths[product]
        orders: List[Order] = []

        if len(order_depth.sell_orders) != 0:
            best_ask, best_ask_amount = list(order_depth.sell_orders.items())[0]
            if int(best_ask) < fair_price:
                print("BUY", str(-best_ask_amount) + "x", best_ask)
                orders.append(Order(product, best_ask, -best_ask_amount))

        if len(order_depth.buy_orders) != 0:
            best_bid, best_bid_amount = list(order_depth.buy_orders.items())[0]
            if int(best_bid) > fair_price:
                print("SELL", str(best_bid_amount) + "x", best_bid)
                orders.append(Order(product, best_bid, -best_bid_amount))

        return orders

    def post_orders(self, fair_price: float, product: str, state: TradingState):
        """
        Post liquidity to the market
        """
        order_depth: OrderDepth = state.order_depths[product]
        orders: List[Order] = []

        return orders

    def run(self, state: TradingState):
        """Only method required. It takes all buy and sell orders for all
        symbols as an input, and outputs a list of orders to be sent."""

        print("traderData: " + state.traderData)
        print("Observations: " + str(state.observations))

        # Orders to be placed on exchange matching engine
        result = {}
        for product in state.order_depths:
            # Total orders for this product
            orders: List[Order] = []

            # Display current orders on market
            order_depth: OrderDepth = state.order_depths[product]
            print(
                "Buy Order depth : "
                + str(len(order_depth.buy_orders))
                + ", Sell order depth : "
                + str(len(order_depth.sell_orders))
            )

            # Get the fair price for the product
            acceptable_price = self._get_fair_price(product, state)
            print("Acceptable price : " + str(acceptable_price))

            # Generate orders - take liquidity from the market
            orders_take = self.take_orders(acceptable_price, product, state)
            orders.extend(orders_take)

            # Generate orders - post liquidity to the market
            orders_post = self.post_orders(acceptable_price, product, state)
            orders.extend(orders_post)

            result[product] = orders

        # String value holding Trader state data required.
        # It will be delivered as TradingState.traderData on next execution.
        traderData = "SAMPLE"

        # Sample conversion request. Check more details below.
        conversions = 1
        return result, conversions, traderData